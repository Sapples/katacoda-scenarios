# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

import re
import requests_mock

from iotic.lib.identity import Document

from .const import RESOLVER, MOCK_RESOLVER_ADDR


def get_resolver(identities):
    return MockedResolver(identities) if RESOLVER == MOCK_RESOLVER_ADDR else RealResolver(identities)


class MockedResolver:

    def __init__(self, identities):
        self.calls = 0
        self.docs = {doc.id: doc.token for doc in identities}
        self._mocker = requests_mock.Mocker()

    def reset(self):
        self.calls = 0

    def _fetch_cb(self, request, context):
        self.calls += 1
        context.status_code = 200
        try:
            return {'token': self.docs[request.path_url.rsplit('/', maxsplit=1)[-1]]}
        except KeyError:
            context.status_code = 404
            return {}

    def __enter__(self):
        mock = self._mocker.__enter__()
        mock.register_uri('GET', re.compile(fr'^{RESOLVER}/1\.0/discover/'), json=self._fetch_cb)
        return self

    def __exit__(self, *args, **kwargs):
        self._mocker.__exit__(*args, **kwargs)


class RealResolver:

    def __init__(self, identities):
        self.calls = 0
        for doc in identities:
            Document.Resolver.register(doc.token)

    def __discover_wrapper(self, *args, **kwargs):
        self.calls += 1
        return self._org_discover_func(*args, **kwargs)

    def reset(self):
        self.calls = 0

    def __enter__(self):
        self._org_discover_func = Document.Resolver.discover  # pylint: disable=attribute-defined-outside-init
        Document.Resolver.discover = self.__discover_wrapper
        return self

    def __exit__(self, *args, **kwargs):
        Document.Resolver.discover = self._org_discover_func
