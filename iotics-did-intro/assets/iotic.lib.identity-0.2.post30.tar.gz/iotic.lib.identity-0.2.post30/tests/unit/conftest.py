# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

import os
import json
import logging


def vector_const():
    """vector_const: Load test vectors json"""
    try:
        file_path = os.path.join(os.curdir, '..', '..', 'test_vectors.json')
        with open(file_path) as fpr:
            return json.load(fpr)
    except (json.JSONDecodeError, TypeError) as err:
        logging.error('Invalid json spec from %s', file_path)
        raise err
    except OSError as err:
        logging.error('Can not load file %s', file_path)
        raise err
