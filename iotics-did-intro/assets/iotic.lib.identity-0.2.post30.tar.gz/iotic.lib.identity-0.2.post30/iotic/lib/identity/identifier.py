# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from enum import Enum, unique
import secrets
import re

from mnemonic import Mnemonic

from hashlib import sha256, sha512, blake2b
import hmac

import base58

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

# todo: Remove this.
# It is used to loading public keys in x962 format while cryptography library can't
# Needs more investigation, how to import uncompressed ecdsa public key DER (04... 65 bytes) with cryptography
import ecdsa

# DID Identifier Prefix
IDENTIFIER_PREFIX = 'did:iotics:'

# Path prefix
IDENTIFIER_PATH = 'iotics/0'

# Curve
IDENTIFIER_CURVE = ec.SECP256K1()

# Regex pattern for valid #name
NAME_PATTERN_RAW = r'[a-zA-Z\-\_0-9]{1,24}'
IDENTIFIER_NAME_PATTERN = fr'^\#{NAME_PATTERN_RAW}$'

# Regex pattern for DID identifier
IDENTIFIER_ID_PATTERN = fr'^did:iotics:iot(?P<hash>[a-km-zA-HJ-NP-Z1-9]{{33}})(?P<keyname>#{NAME_PATTERN_RAW})?$'

# Length of iot hash
IDENTIFIER_VALID_LENGTH = 36


@unique
class SeedMethod(Enum):
    SEED_METHOD_NONE = 0
    SEED_METHOD_BIP39 = 1


@unique
class DIDType(Enum):
    """DIDType: enum for valid DID Document types"""
    HOST = 'host'
    USER = 'user'
    AGENT = 'agent'
    TWIN = 'twin'

    def __str__(self):
        return self.value


def make_identifier(public_hex: str) -> str:
    """make_identifier: Take public key hex (DER) and return iotics DID identifier string"""
    method = 0x05
    version = 0x55
    pad = 0x59

    bl2 = blake2b(digest_size=20)
    bl2.update(bytearray.fromhex(public_hex))
    pkdigest = bl2.digest()

    cl2 = blake2b(digest_size=20)
    cl2.update(pkdigest)
    checksum = bytearray.fromhex(cl2.hexdigest())[:4]

    return IDENTIFIER_PREFIX + base58.b58encode(bytes([method, version, pad]) + pkdigest + checksum).decode('ascii')


def compare_identifier_only(id_a: str, id_b: str) -> bool:
    """compare_identifier_only: Compares two DID Identifiers ignoring name returns bool"""
    return id_a.split('#')[0] == id_b.split('#')[0]


def split_name_off_id(id_a: str) -> str:
    """split_name_off_id: Get the key name off a DID ID string or None"""
    if '#' in id_a:
        return '#' + id_a.split('#')[1]
    return None


def validate_identifier(id_a: str) -> bool:
    """validate_identifier: Takes DID Identifier string and returns True or raises exception"""
    # todo: does not handle customer name eg did:iotics:(customer):hash
    result = re.match(IDENTIFIER_ID_PATTERN, id_a)
    if result is None:
        raise ValueError(f'Identifier does not match pattern {IDENTIFIER_ID_PATTERN}')
    return True


def validate_key_name(name: str) -> bool:
    """validate_key_name: Takes a key name like '#key' and checks valid length & characters"""
    m = re.match(IDENTIFIER_NAME_PATTERN, name)
    if m is None:
        raise ValueError('Identifier name is not valid')
    return True


def new_seed(length: int = 128) -> str:
    """new_seed: Make a new random seed length 128 or 256 bits returns hex string"""
    if length not in (128, 256):
        raise ValueError('length must be 128 or 256')
    return secrets.token_hex(nbytes=int(length / 8))


def seed_to_mnemonic(seed_hex: str, lang: str = 'english') -> str:
    """seed_to_mnemonic: Take seed string hex and return mnemonic string"""
    byt = bytes.fromhex(seed_hex)
    men = Mnemonic(lang)
    return men.to_mnemonic(byt)


def mnemonic_to_seed(mnemonic: str, lang: str = 'english') -> str:
    """mnemonic_to_seed: Take mnemonic string and return seed string hex"""
    men = Mnemonic(lang)
    byt = men.to_entropy(mnemonic)
    return byt.hex()


def seed_to_master(seed_hex: str, password: bytes = b"", method: SeedMethod = SeedMethod.SEED_METHOD_BIP39) -> bytes:
    """seed_to_master: Takes seed hex and optional password and returns master bytes 512-bit"""
    result = None
    if method == SeedMethod.SEED_METHOD_NONE:
        # SEED_METHOD_NONE is for backwards compatibility with identities made before 0.0.1
        byt = bytearray.fromhex(seed_hex)
        result = hmac.new(byt, password, sha512).digest()

    elif method == SeedMethod.SEED_METHOD_BIP39:
        # SEED_METHOD_BIP39 is bip39 standard seed-to-master function
        mstr = seed_to_mnemonic(seed_hex)
        result = Mnemonic.to_seed(mstr, password)

    else:
        raise ValueError(f'seed method must be in {[v.name for v in SeedMethod]}')

    return result


def new_private_hex_from_path(master: bytes, purpose: str, count: int) -> str:
    """new_private_hex_from_path: Takes master bytes, purpose and count and returns new private key str hex"""
    return new_private_hex_from_path_str(master, purpose, f'{count:02}')


def new_private_hex_from_path_str(master: bytes, purpose: str, name: str) -> str:
    """new_private_hex_from_path_str: Takes master bytes, purpose and string and returns new private key str hex"""
    DIDType(purpose)
    path = f'{IDENTIFIER_PATH}/{purpose}/{name}'.encode('utf8')
    return hmac.new(master, path, sha256).hexdigest()


def private_hex_to_ECDSA(private_hex: str) -> ec.EllipticCurvePrivateKey:
    """private_hex_to_ECDSA: Return ECDSA private key instance from private exponent hex"""
    sbin = bytes.fromhex(private_hex)
    sint = int.from_bytes(sbin, 'big', signed=False)
    return ec.derive_private_key(sint, IDENTIFIER_CURVE, default_backend())


def public_ECDSA_to_bytes(public_ecdsa: ec.EllipticCurvePublicKey) -> bytes:
    """public_ECDSA_to_bytes: Takes a public key and returns DER uncompressed bytes"""
    return public_ecdsa.public_bytes(encoding=serialization.Encoding.X962,
                                     format=serialization.PublicFormat.UncompressedPoint)


def public_ECDSA_to_base58(public_ecdsa: ec.EllipticCurvePublicKey) -> str:
    """public_ECDSA_to_base58: Takes a public key and returns base58 string of DER uncompressed bytes"""
    return base58.b58encode(public_ECDSA_to_bytes(public_ecdsa)).decode('ascii')


def public_base58_to_ECDSA(public_base58: str) -> ec.EllipticCurvePublicKey:
    """public_base58_to_ECDSA: Takes public base58 and returns instance"""
    return public_bytes_to_ECDSA(base58.b58decode(public_base58))


def public_bytes_to_ECDSA(public_bytes: bytes) -> ec.EllipticCurvePublicKey:
    """public_bytes_to_ECDSA: Takes public bytes and returns instance"""
    evk = ecdsa.VerifyingKey.from_string(public_bytes, curve=ecdsa.SECP256k1)
    vkpem = evk.to_pem()
    return serialization.load_pem_public_key(vkpem, backend=default_backend())


def private_ECDSA_to_public_ECDSA(private_ecdsa: ec.EllipticCurvePrivateKey) -> ec.EllipticCurvePublicKey:
    """private_ECDSA_to_public_ECDSA: Returns public key instance"""
    return private_ecdsa.public_key()
