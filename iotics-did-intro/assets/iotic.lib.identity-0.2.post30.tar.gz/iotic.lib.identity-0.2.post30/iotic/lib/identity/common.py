# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

import jwt

from iotic.lib.identity.exceptions import InvalidSignatureError, ExpiredSignatureError, DecodeError


def verify_token(tkn: str, iss='', aud='', verify=True) -> dict:
    """verify_token: Helper to verify JWT token or raise exception"""
    try:
        return jwt.decode(tkn, iss, audience=aud, algorithms=['ES256'], verify=verify)
    except jwt.exceptions.InvalidSignatureError as exc:
        raise InvalidSignatureError(exc)
    except jwt.exceptions.ExpiredSignatureError as exc:
        raise ExpiredSignatureError(exc)
    except Exception as exc:
        raise DecodeError(exc)
