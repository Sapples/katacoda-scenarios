# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from datetime import datetime

import jwt

from cryptography.hazmat.primitives.asymmetric import ec

from iotic.lib.identity import Identifier
from iotic.lib.identity import Document
from iotic.lib.identity import Resolver
from iotic.lib.identity.exceptions import DecodeError, NotAllowed

from .common import verify_token

# Max duration (secs) of authentication token
MAX_DURATION = 86400


def new_challenge_token(iss: str, aud: str, proof: str, private_ecdsa: ec.EllipticCurvePrivateKey) -> str:
    """new_challenge_token: Make a challenge token for issuer to work on audiences behalf"""
    return jwt.encode({'iss': iss, 'aud': aud, 'proof': proof}, private_ecdsa, algorithm='ES256')


def verify_challenge(tkn: str) -> dict:
    """verify_challenge: Verify challenge token"""
    unverified = verify_token(tkn, verify=False)
    for field in ('iss', 'aud'):
        if field not in unverified:
            raise DecodeError(f'Token missing {field}')

    iss_key = Document.find_issuer_by_id(unverified['iss'], unverified['iss'], True)
    if iss_key is None:
        return None

    verified = verify_token(tkn, iss_key.public_key, unverified['aud'])

    return {'iss': verified['iss'],
            'aud': verified['aud'],
            'proof': verified['proof']}


def new_authentication_token(iss: str, sub: str, aud: str, duration: int,
                             private_ecdsa: ec.EllipticCurvePrivateKey) -> str:
    """new_authentication_token: Make a token for issuer to authenticate as subject to audience"""
    tnow = int(datetime.now().timestamp())
    if 0 < duration > MAX_DURATION:
        raise ValueError(f'Duration must be >0 and <{MAX_DURATION}')
    return jwt.encode({
        'iss': iss,
        'aud': aud,
        'sub': sub,
        'iat': tnow,
        'exp': tnow + duration
    }, private_ecdsa, algorithm='ES256')


def verify_authentication(tkn: str) -> dict:
    """verify_authentication: Verify authentication token"""
    unverified = verify_token(tkn, verify=False)
    for field in ('iss', 'sub', 'aud', 'iat', 'exp'):
        if field not in unverified:
            raise DecodeError(f'Token missing {field}')

    iss_key = Document.find_issuer_by_id(unverified['iss'], unverified['iss'], False, False)
    if iss_key is None:
        return None

    verified = verify_token(tkn, iss_key.public_key, unverified['aud'])

    if not check_allowed(verified['iss'], verified['sub'], False, False):
        raise NotAllowed('Not allowed')

    return {'iss': verified['iss'],
            'sub': verified['sub'],
            'aud': verified['aud'],
            'iat': verified['iat'],
            'exp': verified['exp']}


def check_allowed(iss: str, sub: str, control_only: bool = True, full: bool = True) -> bool:
    """check_allowed: Fetch the subject document and check issuer is allowed to auth or control
    This is similar to find_issuer but does not return public key.
    This checks that issuer is allowed to work on behalf of issuer according to Suject DID Doc.
    It should be called AFTER checking authentication (eg after find_issuer_ / verify_token)
    This is implemented in the SDK to save users like iotic-web/rest from implementing this logic.

    Warning: This is not a security function! No cryptograhic proof is required for check_allowed!

    iss: Issuer ID who made the token (eg Agent DID # Agent Key)
    sub: Subject ID who iss wants to control/auth. (Subject DID)
    control_only: True for control, False for Auth
    """
    iss_name = Identifier.split_name_off_id(iss)
    if iss_name is None:
        raise ValueError('Issuer must have #name')

    sub_doc = Resolver.discover(sub, full)
    iss_doc = Resolver.discover(iss, full)

    if iss_doc.revoked or sub_doc.revoked:
        return False

    if sub_doc.controller is not None:
        if Identifier.compare_identifier_only(iss, sub_doc.controller):
            return check_allowed(iss, sub_doc.controller, control_only, full)

    if Identifier.compare_identifier_only(iss, sub):
        keylist = sub_doc.public_keys
        if not control_only:
            keylist = keylist + sub_doc.authentication_keys

        for k in keylist:
            if iss_name == k.id:
                return True

    deleglist = sub_doc.delegate_control
    if not control_only:
        deleglist = deleglist + sub_doc.delegate_authentication

    for k in deleglist:
        if k.revoked:
            continue
        if Identifier.compare_identifier_only(iss, sub) and iss_name == k.id:
            return True
        if Identifier.compare_identifier_only(iss, k.controller):
            return True

    return False
