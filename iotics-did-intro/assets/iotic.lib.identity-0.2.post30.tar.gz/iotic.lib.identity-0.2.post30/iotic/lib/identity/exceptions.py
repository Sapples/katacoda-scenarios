# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.


class IdentityBaseException(Exception):
    """IdentityBaseException: Base of all iotic.lib.identity exceptions"""


class InvalidSignatureError(IdentityBaseException):
    """InvalidSignatureError: Raised when unable to verify signature on JWT token"""


class ExpiredSignatureError(IdentityBaseException):
    """ExpiredSignatureError: Raised when token is expired"""


class DecodeError(IdentityBaseException):
    """DecodeError: Raised when token cannot be decoded"""


class NotAllowed(IdentityBaseException):
    """NotAllowed: Raised for valid auth' tokens that are not allowed because eg no delegation"""


class IdentityNotFound(IdentityBaseException):
    """IdentityNotfound: Raised when resolver returns 404"""
