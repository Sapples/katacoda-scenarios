# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from time import time as unixtime
from collections import namedtuple
from os import environ

import requests
import base64
import base58
import jwt

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.exceptions import InvalidSignature

from iotic.lib.identity import Identifier
from iotic.lib.identity.exceptions import DecodeError, IdentityNotFound

from .common import verify_token

# Environemt variable name for resolver address
RESOLVER_ENV = 'RESOLVER'

# @context string for DID document
DOCUMENT_CONTEXT = 'https://w3id.org/did/v1'

# Spec version
DOCUMENT_VERSION = '0.0.1'

# DOCUMENT_PUBLICKEY_TYPE key type string for public key section
DOCUMENT_PUBLICKEY_TYPE = 'Secp256k1VerificationKey2018'

# DOCUMENT_AUTHENTICATION_TYPE key type string for authentication section
DOCUMENT_AUTHENTICATION_TYPE = 'Secp256k1SignatureAuthentication2018'

# DOCUMENT_MAX_FINDISSUER_DEPTH limits how many documents down the FindIssuer function will look
DOCUMENT_MAX_FINDISSUER_DEPTH = 5

# Metadata validation
DOCUMENT_MAX_LABEL_LENGTH = 64
DOCUMENT_MAX_COMMENT_LENGTH = 512
DOCUMENT_MAX_URL_LENGTH = 512


class KeyID:
    """KeyID: """
    def __init__(self, name: str, key_type: str, public_base58: str, revoked: bool = False):
        self.__name = name
        self.__key_type = key_type
        self.__public_base58 = public_base58
        self.__revoked = revoked
        self.validate()

    def __dict__(self):
        ret = {
            'id': self.__name,
            'type': self.__key_type,
            'publicKeyBase58': self.__public_base58,
            'revoked': self.__revoked,
        }
        return ret

    def validate(self):
        """validate: """
        Identifier.validate_key_name(self.__name)

        if self.__key_type not in (DOCUMENT_AUTHENTICATION_TYPE, DOCUMENT_PUBLICKEY_TYPE):
            raise ValueError('key type not valid')

        Identifier.public_base58_to_ECDSA(self.__public_base58)

        if not (self.__revoked is None or self.__revoked is True or self.__revoked is False):
            raise ValueError('revoked must be True/False')

    @property
    def id(self):
        return self.__name

    @property
    def type(self):
        return self.__key_type

    @property
    def revoked(self) -> bool:
        return self.__revoked if self.__revoked else False

    @revoked.setter
    def revoked(self, val: bool):
        if not isinstance(val, bool):
            raise ValueError('revoked must be True/False')
        self.__revoked = val

    @property
    def public_base58(self):
        return self.__public_base58


class Delegation:
    """Delegation: """
    def __init__(self, name: str, controller: str, proof: str, revoked=None):
        self.__id = name
        self.__controller = controller
        self.__proof = proof
        self.__revoked = revoked
        self.validate()

    def __dict__(self):
        ret = {'id': self.__id, 'controller': self.__controller, 'proof': self.__proof}
        if self.__revoked is not None:
            ret['revoked'] = self.__revoked
        return ret

    def validate(self, parent_id=None, controller_doc=None):
        """validate: """
        Identifier.validate_key_name(self.__id)
        Identifier.validate_identifier(self.__controller)

        if parent_id is not None:
            if Identifier.compare_identifier_only(parent_id, self.__controller):
                raise ValueError('Delegate to self not allowed')

            if controller_doc is None:
                controller_doc = Resolver.discover(self.__controller, full=False)

            valid_proof = False
            for k in controller_doc.public_keys:
                if verify_proof(self.__proof, parent_id.encode('ascii'), k.public_base58):
                    valid_proof = True
                    break
            # todo: check delegate_control keys
            if not valid_proof:
                raise ValueError('Delegation proof not valid')

        if self.__revoked is not None:
            if not isinstance(self.__revoked, bool):
                raise ValueError('revoked is not bool')

        return True

    @property
    def id(self):
        return self.__id

    @property
    def controller(self) -> str:
        return self.__controller

    @property
    def revoked(self) -> bool:
        return self.__revoked if self.__revoked else False

    @revoked.setter
    def revoked(self, val: bool):
        if not isinstance(val, bool):
            raise ValueError('revoked must be True/False')
        self.__revoked = val


class Metadata:
    """Metadata: """
    def __init__(self, label: str = '', comment: str = '', url: str = ''):
        self.__label = label
        self.__comment = comment
        self.__url = url
        self.validate()

    def __dict__(self):
        ret = {}
        if len(self.__label) > 0:
            ret['label'] = self.__label
        if len(self.__comment) > 0:
            ret['comment'] = self.__comment
        if len(self.__url) > 0:
            ret['url'] = self.__url
        return ret

    def validate(self):
        """validate: """
        self.__label.encode('ascii')
        self.__comment.encode('ascii')
        self.__url.encode('ascii')
        if len(self.__label) > DOCUMENT_MAX_LABEL_LENGTH:
            raise ValueError('Label is too long')
        if len(self.__comment) > DOCUMENT_MAX_COMMENT_LENGTH:
            raise ValueError('Comment is too long')
        if len(self.__url) > DOCUMENT_MAX_URL_LENGTH:
            raise ValueError('URL is too long')

    @property
    def label(self):
        return self.__label

    @label.setter
    def label(self, label):
        self.__label = label
        self.validate()

    @property
    def comment(self):
        return self.__comment

    @comment.setter
    def comment(self, comment):
        self.__comment = comment
        self.validate()

    @property
    def url(self):
        return self.__url

    @url.setter
    def url(self, url):
        self.__url = url
        self.validate()


# DIDDocumentValid: namedtuple to contain result of DIDDocument.validate function
# valid bool
# valid_new bool means the doc contains the original key and the doc is not revoked
DIDDocumentValid = namedtuple('DIDDocumentValid', 'valid valid_new')


# DIDDocumentClaims: namedtuple to contain result of verify_document function
DIDDocumentClaims = namedtuple('DIDDocumentClaims', 'iss aud doc')


class DIDDocument:  # pylint: disable=R0902,R0904
    """DIDDocument: """
    def __init__(self, did_type: Identifier.DIDType, did_id: str, proof: str, key_id: KeyID):
        self.__did_type = did_type
        self.__did_id = did_id
        self.__spec_version = DOCUMENT_VERSION
        self.__proof = proof
        self.__public_key = {key_id.id: key_id}
        self.__update_time = None

        self.__authentication_key = {}
        self.__delegate_control = {}
        self.__delegate_authentication = {}
        self.__metadata = Metadata()

        # These fields will be ommitted from the json if empty
        self.__controller = None
        self.__revoked = None
        self.__creator = None

        self.validate()

    def __dict__(self):
        if self.__update_time is None:
            self.__update_time = int(unixtime() * 1000)
        ret = {
            '@context': DOCUMENT_CONTEXT,
            'id': self.__did_id,
            'ioticsSpecVersion': self.__spec_version,
            'ioticsDIDType': str(self.__did_type),
            'updateTime': self.__update_time,
            'proof': self.__proof,
            'publicKey': [k.__dict__() for _, k in self.__public_key.items()],
            'authentication': [k.__dict__() for _, k in self.__authentication_key.items()],
            'delegateControl': [k.__dict__() for _, k in self.__delegate_control.items()],
            'delegateAuthentication': [k.__dict__() for _, k in self.__delegate_authentication.items()],
            'metadata': self.__metadata.__dict__(),  # pylint: disable=E1102
            # ^ Note: Disabled E1102 Not Callable.  Not sure why lint complains.
        }
        if self.__controller is not None:
            ret['controller'] = self.__controller
        if self.__revoked is not None:
            ret['revoked'] = self.__revoked
        if self.__creator is not None:
            ret['creator'] = self.__creator
        return ret

    @property
    def id(self):
        return self.__did_id

    @property
    def did_type(self):
        return self.__did_type

    @property
    def update_time(self):
        return self.__update_time

    @update_time.setter
    def update_time(self, upd: int):
        if self.__update_time is None or upd > self.__update_time:
            self.__update_time = upd
            return
        raise ValueError('update_time can only be increased')

    @property
    def spec_version(self):
        return self.__spec_version

    @spec_version.setter
    def spec_version(self, version):
        self.__validate_spec_version(version)
        self.__spec_version = version

    @classmethod
    def __validate_spec_version(cls, version):
        supported_versions = ('0.0.0', DOCUMENT_VERSION)
        if version not in supported_versions:
            raise ValueError(f'Unsupported version {version} not in {supported_versions}')

    @property
    def controller(self):
        return self.__controller

    @controller.setter
    def controller(self, cont: str):
        if self.__controller is None:
            if Identifier.validate_identifier(cont):
                self.__controller = cont
                return
        raise ValueError('Cannot change controller once set')

    @property
    def revoked(self) -> bool:
        return self.__revoked if self.__revoked else False

    @revoked.setter
    def revoked(self, revoked: bool):
        if not self.__revoked and revoked is True:
            self.__revoked = True
            return
        raise ValueError('Revoked cannot be unset once true')

    @property
    def creator(self):
        return self.__creator

    # todo: This can be changed, but cannot be unset due to validation.
    @creator.setter
    def creator(self, creator: str):
        if Identifier.validate_identifier(creator):
            self.__creator = creator

    @property
    def metadata(self):
        return Metadata(self.__metadata.label, self.__metadata.comment, self.__metadata.url)

    @metadata.setter
    def metadata(self, metadata: Metadata):
        if metadata.validate():
            self.__metadata = metadata

    @property
    def public_keys(self):
        return list(self.__public_key.values())

    @property
    def authentication_keys(self):
        return list(self.__authentication_key.values())

    @property
    def delegate_control(self):
        return list(self.__delegate_control.values())

    @property
    def delegate_authentication(self):
        return list(self.__delegate_authentication.values())

    def validate(self, full: bool = True) -> DIDDocumentValid:
        """validate: Returns namedtuple (valid, valid_new)

        if optional full is True then all the signatures will be verified and valid_new can be set
        if full is False then valid_new will always be false.
        """
        valid = True
        valid_new = False

        Identifier.validate_identifier(self.__did_id)
        self.__validate_spec_version(self.__spec_version)

        if not isinstance(self.__did_type, Identifier.DIDType):
            raise ValueError('did_type is not valid')

        if self.__revoked is not None:
            if not isinstance(self.__revoked, bool):
                raise ValueError('revoked is not valid')

        if self.__metadata is not None:
            self.__metadata.validate()

        # Check if controller or atleast one public key
        if self.__controller is None or not Identifier.validate_identifier(self.__controller):
            if len(self.__public_key) == 0:
                raise ValueError('No Controller or Public Keys')

        # Check all the key names are unique
        if not self.__check_unique_name():
            return DIDDocumentValid(valid=False, valid_new=False)

        # Verify proof / check for original key
        for k in self.__public_key.values():
            k.validate()
            pkb = base58.b58decode(k.public_base58).hex()
            kid = Identifier.make_identifier(pkb)
            if full and kid == self.__did_id:
                if verify_proof(self.__proof, self.__did_id.encode('ascii'), k.public_base58):
                    valid_new = True
                else:
                    raise ValueError('Found original key but proof not valid')
                break

        for k in self.__authentication_key.values():
            k.validate()

        for k in self.__delegate_control.values():
            k.validate(parent_id=self.id if full else None)

        for k in self.__delegate_authentication.values():
            k.validate(parent_id=self.id if full else None)

        return DIDDocumentValid(valid=valid, valid_new=valid_new)

    def __check_unique_name(self, name: str = '') -> bool:
        """__check_unique_name: Checks all the key names in this doc are unique and name is not found"""
        allkey = (self.__public_key,
                  self.__authentication_key,
                  self.__delegate_control,
                  self.__delegate_authentication)
        return not any(name in k for k in allkey)

    def add_public_key(self, key_id: KeyID) -> bool:
        key_id.validate()
        if self.__check_unique_name(key_id.id):
            self.__public_key[key_id.id] = key_id
            return True
        return False

    def remove_public_key(self, key_name: str) -> bool:
        return bool(self.__public_key.pop(key_name, None))

    def add_authentication_key(self, key_id: KeyID) -> bool:
        key_id.validate()
        if self.__check_unique_name(key_id.id):
            self.__authentication_key[key_id.id] = key_id
            return True
        return False

    def remove_authentication_key(self, key_name: str) -> bool:
        return bool(self.__authentication_key.pop(key_name, None))

    def add_control_delegation(self, delegation: Delegation) -> bool:
        delegation.validate()
        if self.__check_unique_name(delegation.id):
            self.__delegate_control[delegation.id] = delegation
            return True
        return False

    def remove_control_delegation(self, key_name: str) -> bool:
        return bool(self.__delegate_control.pop(key_name, None))

    def add_authentication_delegation(self, delegation: Delegation) -> bool:
        delegation.validate()
        if self.__check_unique_name(delegation.id):
            self.__delegate_authentication[delegation.id] = delegation
            return True
        return False

    def remove_authentication_delegation(self, key_name: str) -> bool:
        return bool(self.__delegate_authentication.pop(key_name, None))


class Resolver:
    @classmethod
    def get_resolver_from_env(cls):
        """get_resolver_from_env: Returns resolver addr or raises KeyError"""
        return environ[RESOLVER_ENV]  # TODO: Url builder or atleast validate/strip-final-slash blah

    @classmethod
    def discover(cls, did: str, full: bool = True) -> DIDDocument:
        """discover: Calls the resolver and returns DIDDocument instance or None"""
        addr = Resolver.get_resolver_from_env()
        did_id = did.split('#')[0]
        Identifier.validate_identifier(did_id)
        resp = requests.get(f'{addr}/1.0/discover/{did_id}')
        try:
            resp.raise_for_status()
        except requests.exceptions.HTTPError as exc:
            raise IdentityNotFound(f'Identity {did} not found') from exc
        tkn = resp.json()['token']
        claims = verify_document(tkn, full)
        if claims is None:
            return None
        return claims.doc

    @classmethod
    def register(cls, tkn: str) -> bool:
        """register: Register a DDO with the resolver"""
        addr = Resolver.get_resolver_from_env()
        resp = requests.post(f'{addr}/1.0/register', data=tkn, headers={'Content-type': 'text/plain'})
        resp.raise_for_status()
        return resp.json()


class IssuerKey:
    """IssuerKey: Returned by find_issuer_* functions for consistency with other sdk impls"""
    def __init__(self, public_base58: str, issuer_id: str, revoked: bool):
        self.__public_base58 = public_base58
        self.__public_key = Identifier.public_base58_to_ECDSA(public_base58)
        self.__issuer_id = issuer_id
        self.__revoked = revoked

    @property
    def public_key(self):
        return self.__public_key

    @property
    def public_base58(self):
        return self.__public_base58

    @property
    def issuer_id(self):
        return self.__issuer_id

    @property
    def revoked(self) -> bool:
        return self.__revoked if self.__revoked else False

    def matches(self, public_ecdsa: ec.EllipticCurvePublicKey) -> bool:
        cmp_base58 = Identifier.public_ECDSA_to_base58(public_ecdsa)
        return self.__public_base58 == cmp_base58


def new_did_document(did_type: Identifier.DIDType,
                     private_ecdsa: ec.EllipticCurvePrivateKey,
                     name: str = '') -> DIDDocument:
    """new_did_document: Returns a new DIDDocument instance"""
    # Make default name if not specified
    if len(name) == 0:
        name = f'#{did_type}-0'

    # Make identifier
    public_ecdsa = Identifier.private_ECDSA_to_public_ECDSA(private_ecdsa)
    public_bytes = Identifier.public_ECDSA_to_bytes(public_ecdsa)
    public_base58 = Identifier.public_ECDSA_to_base58(public_ecdsa)
    did_identifier = Identifier.make_identifier(public_bytes.hex())

    # Make proof
    proof = new_proof(did_identifier.encode('ascii'), private_ecdsa)

    # Public key
    key_id = new_keyid_publickey(name, public_base58)

    return DIDDocument(did_type, did_identifier, proof, key_id)


def new_document_token(ddo: DIDDocument, aud: str, iss: str, private_ecdsa: ec.EllipticCurvePrivateKey) -> str:
    """new_document_token: Takes a DIDDocument instance and returns a jwt for registering with the resolver"""
    return jwt.encode({'iss': iss, 'aud': aud, 'doc': ddo.__dict__()}, private_ecdsa, algorithm='ES256').decode('ascii')


def new_proof(content: bytes, private_ecdsa: ec.EllipticCurvePrivateKey) -> str:
    """new_proof: Return base64 encoded signature of sha256(content)
    Note: Signature format is ASN1(R,S)
    """
    sig = private_ecdsa.sign(content, ec.ECDSA(hashes.SHA256()))
    return base64.b64encode(sig).decode('ascii')


def verify_proof(proof: str, content: bytes, public_key_base58: str) -> bool:
    """verify_proof: Takes base64 encoded proof, content bytes and public key base58 to verify proof signature
    returns true/false
    """
    pub_key = Identifier.public_base58_to_ECDSA(public_key_base58)
    signature = base64.b64decode(proof)
    try:
        pub_key.verify(signature, content, ec.ECDSA(hashes.SHA256()))
    except InvalidSignature:
        return False
    return True


def new_keyid_publickey(name: str, public_base58: str, revoked: bool = False) -> KeyID:
    """new_keyid_publickey: Helper to make KeyID instance"""
    return KeyID(name, DOCUMENT_PUBLICKEY_TYPE, public_base58, revoked)


def new_keyid_authentication(name: str, public_base58: str, revoked: bool = False) -> KeyID:
    """new_keyid_authentication: Helper to make KeyID instance"""
    return KeyID(name, DOCUMENT_AUTHENTICATION_TYPE, public_base58, revoked)


def new_delegation(name: str, controller: str, proof: str, revoked: bool = False) -> Delegation:
    """new_delegation: Helper to make Delegation instance"""
    return Delegation(name, controller, proof, revoked)


def verify_document(tkn: str, full: bool = True) -> DIDDocumentClaims:
    """verify_document: Take a DDO token string and return DIDDocument instance or raise"""
    # Build doc from decoded JWT
    unverified = jwt.decode(tkn, verify=False)
    for field in ['iss', 'aud', 'doc']:
        if field not in unverified:
            raise DecodeError(f'Token missing {field}')

    key_id = KeyID(unverified['doc']['publicKey'][0]['id'], unverified['doc']['publicKey'][0]['type'],
                   unverified['doc']['publicKey'][0]['publicKeyBase58'])
    doc = DIDDocument(Identifier.DIDType(unverified['doc']['ioticsDIDType']), unverified['doc']['id'],
                      unverified['doc']['proof'], key_id)
    doc.spec_version = unverified['doc']['ioticsSpecVersion']

    doc.update_time = unverified['doc']['updateTime']

    if 'revoked' in unverified['doc']:
        doc.revoked = unverified['doc']['revoked']
    if 'controller' in unverified['doc']:
        doc.controller = unverified['doc']['controller']
    if 'creator' in unverified['doc']:
        doc.creator = unverified['doc']['creator']

    for k in unverified['doc']['publicKey'][1:]:
        doc.add_public_key(KeyID(k['id'], k['type'], k['publicKeyBase58']))
    if 'authentication' in unverified['doc']:
        for k in unverified['doc']['authentication']:
            doc.add_authentication_key(KeyID(k['id'], k['type'], k['publicKeyBase58']))

    for j in ['delegateControl', 'delegateAuthentication']:
        if j not in unverified['doc']:
            continue
        for k in unverified['doc'][j]:
            revoked = None
            if 'revoked' in k:
                revoked = k['revoked']
            deleg = Delegation(k['id'], k['controller'], k['proof'], revoked)
            if j == 'delegateControl':
                doc.add_control_delegation(deleg)
            else:
                doc.add_authentication_delegation(deleg)

    if not doc.validate(full):
        return None  # TODO: raise ?

    iss_key = find_issuer_by_doc(doc, unverified['iss'], True, full)
    if iss_key is None:
        return None  # TODO: raise ?

    verify_token(tkn, iss_key.public_key, unverified['aud'])

    return DIDDocumentClaims(iss=unverified['iss'],
                             aud=unverified['aud'],
                             doc=doc)


def find_issuer_by_id(did: str, iss: str, control_only: bool, full: bool = True, depth: int = 0) -> IssuerKey:
    """find_issuer_by_id: Fetch DDO by ID and call find_issuer_by_doc"""
    doc = Resolver.discover(did, full)
    return find_issuer_by_doc(doc, iss, control_only, full, depth)


def find_issuer_by_doc(doc: DIDDocument, iss: str, control_only: bool, full: bool = True, depth: int = 0) -> IssuerKey:
    """find_issuer_by_doc: Find if this issuer (iss) given the document"""
    depth = depth + 1
    if depth > DOCUMENT_MAX_FINDISSUER_DEPTH:
        raise ValueError('Max find issuer depth exceeded')

    if not doc.validate():
        raise ValueError('find_issuer document not valid')

    iss_name = Identifier.split_name_off_id(iss)
    if iss_name is None:
        raise ValueError('Issuer must have #name')

    # Check if this document is the issuer!
    if Identifier.compare_identifier_only(doc.id, iss):

        keylist = doc.public_keys
        if not control_only:
            keylist = keylist + doc.authentication_keys

        for k in keylist:
            if k.id == iss_name:
                return IssuerKey(k.public_base58, iss, k.revoked)

        deleglist = doc.delegate_control
        if not control_only:
            deleglist = deleglist + doc.delegate_authentication

        for k in deleglist:
            if k.id == iss_name:
                return find_issuer_by_id(k.controller, k.controller, control_only, full, depth)

    else:
        if doc.controller is not None:
            if Identifier.compare_identifier_only(doc.controller, iss):
                return find_issuer_by_id(doc.controller, iss, control_only, full, depth)

        for k in doc.delegate_authentication + doc.delegate_control:
            if Identifier.compare_identifier_only(k.controller, iss):
                return find_issuer_by_id(k.controller, iss, control_only, full, depth)

    # Issuer Key not found
    return None
